package com.ibm.as400.access;

class AS400JDBCStatementLock extends Object {
    static final String copyright = "Copyright (C) 1997-2003 International Business Machines Corporation and others.";
}
